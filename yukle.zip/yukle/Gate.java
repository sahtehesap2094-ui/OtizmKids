package com.otizm.kids;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.Toast;

/** Ebeveyn koruması: PIN olmadan ayarlara girilemez. */
final class Gate {
    private static EditText pinBox(Activity a) {
        EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setTextSize(30);
        e.setGravity(Gravity.CENTER);
        return e;
    }

    static void ask(Activity a, Runnable ok) {
        if (!Store.hasPin(a)) { setNew(a, ok); return; }
        EditText e = pinBox(a);
        new AlertDialog.Builder(a).setTitle("🔒 Ebeveyn PIN").setView(e)
                .setPositiveButton("Tamam", (d, w) -> {
                    if (Store.checkPin(a, e.getText().toString())) ok.run();
                    else Toast.makeText(a, "Yanlış PIN", Toast.LENGTH_SHORT).show();
                }).setNegativeButton("İptal", null).show();
    }

    static void setNew(Activity a, Runnable ok) {
        EditText e = pinBox(a);
        new AlertDialog.Builder(a).setTitle("Yeni PIN belirle (en az 4 rakam)").setView(e)
                .setPositiveButton("Kaydet", (d, w) -> {
                    String s = e.getText().toString();
                    if (s.length() < 4) { Toast.makeText(a, "En az 4 rakam", Toast.LENGTH_SHORT).show(); return; }
                    Store.setPin(a, s);
                    if (ok != null) ok.run();
                }).setNegativeButton("İptal", null).show();
    }
}
