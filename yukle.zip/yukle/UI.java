package com.otizm.kids;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.widget.Button;

final class UI {
    // Canlı, dikkat çekici renkler
    static final int[] COLORS = {0xFFFF5252, 0xFFFF9800, 0xFFFBC02D, 0xFF43A047,
            0xFF1E88E5, 0xFF8E24AA, 0xFFE91E63, 0xFF00ACC1};
    static final int BG = 0xFFFFF8E1;

    static int dp(Context c, int v) { return (int) (v * c.getResources().getDisplayMetrics().density + .5f); }

    static GradientDrawable round(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    /** Büyük, yuvarlak, renkli buton */
    static Button big(Context c, String text, int color) {
        Button b = new Button(c);
        b.setText(text);
        b.setTextSize(22);
        b.setTypeface(null, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setBackground(round(c, color, 28));
        b.setPadding(dp(c, 16), dp(c, 24), dp(c, 16), dp(c, 24));
        b.setMinHeight(dp(c, 96));
        return b;
    }

    /** Android 15+ kenardan kenara düzen için sistem çubuklarına boşluk bırakır */
    @SuppressWarnings("deprecation")
    static void insets(View v, int padDp) {
        final int p = dp(v.getContext(), padDp);
        v.setPadding(p, p, p, p);
        v.setOnApplyWindowInsetsListener((x, i) -> {
            x.setPadding(p + i.getSystemWindowInsetLeft(), p + i.getSystemWindowInsetTop(),
                    p + i.getSystemWindowInsetRight(), p + i.getSystemWindowInsetBottom());
            return i;
        });
    }
}
