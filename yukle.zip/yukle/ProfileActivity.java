package com.otizm.kids;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/** Çocuğun özellikleri: sevdikleri, sevmedikleri, yapabildikleri, yapamadıkları, kriz tetikleyicileri. */
public class ProfileActivity extends Activity {
    static final String[] TITLES = {
            "😍 Hoşlandıkları", "😖 Hoşlanmadıkları", "💪 Yapabildikleri",
            "🧩 Zorlandıkları / Yapamadıkları", "😡 Sinirlendiren / Kriz Tetikleyen Durumlar",
            "🌈 Sakinleştiren Yöntemler"};
    // Hızlı ekleme önerileri (her çocuk farklıdır; yalnızca örnektir, tanı yerine geçmez)
    static final String[][] SUGGEST = {
            {"Rutinler ve düzen", "Tren / araba", "Müzik", "Harf ve sayılar", "Su oyunları", "Bulmaca", "Eşyaları sıralamak", "Tekrar eden hareketler"},
            {"Yüksek ses", "Parlak / yanıp sönen ışık", "Kalabalık", "Ani değişiklik", "Bazı kumaşlar / dokunuşlar", "Keskin kokular", "Bazı yiyecek dokuları"},
            {"Görsel öğrenme", "Detayları fark etme", "Rutini takip", "İyi hafıza", "Bulmaca / eşleştirme", "Desenleri tanıma"},
            {"Göz teması", "Konuşmayı başlatma", "Sırasını bekleme", "Duygusunu anlatma", "Ani değişime uyum", "Sosyal oyun"},
            {"Rutin bozulması", "Aşırı gürültü", "Aşırı uyaran / kalabalık", "Anlaşılmamak", "İstenmeyen dokunuş", "Beklemek", "Sevdiği eşyanın alınması", "Geçişler (oyundan çıkma)"},
            {"Sessiz köşe", "Kulaklık", "Ağırlıklı battaniye", "Sevdiği oyuncak", "Derin nefes", "Görsel günlük program", "Kısa ve sakin cümleler"}};
    static final int[] COLORS = {UI.COLORS[3], UI.COLORS[0], UI.COLORS[4], UI.COLORS[1], UI.COLORS[6], UI.COLORS[5]};

    private final EditText[] et = new EditText[TITLES.length];
    private EditText name;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(UI.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        sv.addView(root);
        UI.insets(sv, 12);

        name = new EditText(this);
        name.setHint("Çocuğun adı");
        name.setTextSize(22);
        name.setText(Store.get(this, "name"));
        root.addView(name);

        for (int i = 0; i < TITLES.length; i++) {
            TextView t = new TextView(this);
            t.setText(TITLES[i]);
            t.setTextSize(20);
            t.setTypeface(null, Typeface.BOLD);
            t.setTextColor(COLORS[i]);
            t.setPadding(0, UI.dp(this, 20), 0, UI.dp(this, 4));
            root.addView(t);

            final EditText e = new EditText(this);
            et[i] = e;
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            e.setMinLines(3);
            e.setTextSize(18);
            e.setBackground(UI.round(this, Color.WHITE, 16));
            e.setPadding(UI.dp(this, 12), UI.dp(this, 12), UI.dp(this, 12), UI.dp(this, 12));
            e.setText(Store.get(this, "p" + i));

            HorizontalScrollView hs = new HorizontalScrollView(this);
            LinearLayout row = new LinearLayout(this);
            for (String s : SUGGEST[i]) {
                Button chip = UI.big(this, "+ " + s, COLORS[i]);
                chip.setTextSize(14);
                chip.setMinHeight(UI.dp(this, 48));
                chip.setPadding(UI.dp(this, 14), UI.dp(this, 8), UI.dp(this, 14), UI.dp(this, 8));
                chip.setOnClickListener(v -> e.append((e.length() == 0 ? "" : "\n") + "• " + s));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
                lp.setMargins(0, 0, UI.dp(this, 8), UI.dp(this, 8));
                row.addView(chip, lp);
            }
            hs.addView(row);
            root.addView(hs);
            root.addView(e, new LinearLayout.LayoutParams(-1, -2));
        }

        Button save = UI.big(this, "✅ Kaydet", UI.COLORS[3]);
        save.setOnClickListener(v -> {
            Store.put(this, "name", name.getText().toString().trim());
            for (int i = 0; i < et.length; i++) Store.put(this, "p" + i, et[i].getText().toString());
            finish();
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = UI.dp(this, 24);
        root.addView(save, lp);
        setContentView(sv);
    }
}
