package com.otizm.kids;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

/** Çocuğun gördüğü ekran: sadece ebeveynin eklediği uygulamalar, dev renkli butonlarla. */
public class MainActivity extends Activity {

    @Override protected void onResume() { super.onResume(); build(); }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        UI.insets(root, 16);

        String name = Store.get(this, "name");
        TextView title = new TextView(this);
        title.setText("Merhaba" + (name.isEmpty() ? "" : " " + name) + "! 🌈\nNe oynamak istersin?");
        title.setTextSize(28);
        title.setTypeface(null, Typeface.BOLD);
        title.setTextColor(0xFF37474F);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(2);
        PackageManager pm = getPackageManager();
        ArrayList<String> pkgs = new ArrayList<>(Store.allowed(this));
        Collections.sort(pkgs);
        int i = 0;
        for (String pkg : pkgs) {
            Intent li = pm.getLaunchIntentForPackage(pkg);
            if (li == null) continue; // kaldırılmış uygulama
            try {
                Button b = UI.big(this, pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString(),
                        UI.COLORS[i % UI.COLORS.length]);
                Drawable ic = pm.getApplicationIcon(pkg);
                int s = UI.dp(this, 96);
                ic.setBounds(0, 0, s, s);
                b.setCompoundDrawables(null, ic, null, null);
                b.setCompoundDrawablePadding(UI.dp(this, 8));
                b.setOnClickListener(v -> startActivity(li));
                GridLayout.LayoutParams lp = new GridLayout.LayoutParams(
                        GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f));
                lp.width = 0;
                int m = UI.dp(this, 8);
                lp.setMargins(m, m, m, m);
                grid.addView(b, lp);
                i++;
            } catch (PackageManager.NameNotFoundException ignored) { }
        }
        if (i == 0) {
            TextView t = new TextView(this);
            t.setText("Henüz uygulama yok.\nEbeveyn butonuna basılı tutarak ekleyin.");
            t.setTextSize(22);
            t.setGravity(Gravity.CENTER);
            grid.addView(t);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(grid);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        // Yanlışlıkla basılmasın diye basılı tutma gerekir
        Button parent = UI.big(this, "🔒 Ebeveyn (basılı tut)", 0xFF607D8B);
        parent.setTextSize(16);
        parent.setOnClickListener(v -> Toast.makeText(this, "Basılı tutun", Toast.LENGTH_SHORT).show());
        parent.setOnLongClickListener(v -> {
            Gate.ask(this, () -> startActivity(new Intent(this, ParentActivity.class)));
            return true;
        });
        root.addView(parent, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    @Override public void onBackPressed() { /* çocuk geri tuşuyla çıkamasın */ }
}
