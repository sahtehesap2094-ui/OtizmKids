package com.otizm.kids;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Cihazdaki başlatılabilir uygulamaları tarar; ebeveyn seçtiklerini çocuk ekranına ekler. */
public class AppPickerActivity extends Activity {
    private final Map<String, CheckBox> boxes = new HashMap<>();

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        UI.insets(root, 12);

        PackageManager pm = getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(q, 0);
        Set<String> allowed = Store.allowed(this);

        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        for (ResolveInfo ri : apps) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || boxes.containsKey(pkg)) continue;
            CheckBox cb = new CheckBox(this);
            cb.setText(ri.loadLabel(pm));
            cb.setTextSize(22);
            cb.setChecked(allowed.contains(pkg));
            cb.setPadding(UI.dp(this, 8), UI.dp(this, 16), 0, UI.dp(this, 16));
            android.graphics.drawable.Drawable ic = ri.loadIcon(pm);
            int s = UI.dp(this, 48);
            ic.setBounds(0, 0, s, s);
            cb.setCompoundDrawables(ic, null, null, null);
            cb.setCompoundDrawablePadding(UI.dp(this, 12));
            boxes.put(pkg, cb);
            list.addView(cb);
        }
        ScrollView sv = new ScrollView(this);
        sv.addView(list);
        root.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));

        Button save = UI.big(this, "✅ Kaydet", UI.COLORS[3]);
        save.setOnClickListener(v -> {
            Set<String> sel = new HashSet<>();
            for (Map.Entry<String, CheckBox> e : boxes.entrySet())
                if (e.getValue().isChecked()) sel.add(e.getKey());
            Store.setAllowed(this, sel);
            finish();
        });
        root.addView(save, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }
}
