package com.otizm.kids;

import android.content.Context;
import android.content.SharedPreferences;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Set;

final class Store {
    private static SharedPreferences p(Context c) { return c.getSharedPreferences("kids", Context.MODE_PRIVATE); }

    static String get(Context c, String k) { return p(c).getString(k, ""); }
    static void put(Context c, String k, String v) { p(c).edit().putString(k, v).apply(); }

    static Set<String> allowed(Context c) { return new HashSet<>(p(c).getStringSet("apps", new HashSet<>())); }
    static void setAllowed(Context c, Set<String> s) { p(c).edit().putStringSet("apps", s).apply(); }

    static boolean hasPin(Context c) { return !get(c, "pin").isEmpty(); }
    static void setPin(Context c, String pin) { put(c, "pin", hash(pin)); }
    static boolean checkPin(Context c, String pin) { return hash(pin).equals(get(c, "pin")); }

    private static String hash(String s) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(("otizm-salt" + s).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { throw new RuntimeException(e); }
    }
}
