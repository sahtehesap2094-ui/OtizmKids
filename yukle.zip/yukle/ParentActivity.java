package com.otizm.kids;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class ParentActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(UI.BG);
        UI.insets(root, 16);

        add(root, "➕ Uygulama Tara / Ekle", UI.COLORS[4], () -> startActivity(new Intent(this, AppPickerActivity.class)));
        add(root, "🧒 Çocuk Profili", UI.COLORS[3], () -> startActivity(new Intent(this, ProfileActivity.class)));
        add(root, "🔑 PIN Değiştir", UI.COLORS[5], () -> Gate.setNew(this,
                () -> Toast.makeText(this, "PIN değişti", Toast.LENGTH_SHORT).show()));
        add(root, "🏠 Çocuk Ekranına Dön", UI.COLORS[1], this::finish);
        setContentView(root);
    }

    private void add(LinearLayout root, String t, int color, Runnable r) {
        Button b = UI.big(this, t, color);
        b.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, 0, 1f);
        int m = UI.dp(this, 8);
        lp.setMargins(m, m, m, m);
        root.addView(b, lp);
    }
}
